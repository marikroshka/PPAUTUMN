#include <iostream>
using namespace std;

int main() {
    int size;
    cin >> size;
    int arr[size];

    for(int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int maxCount = 0;
    int count[1001] = {0}; 

    for(int i = 0; i < size; i++) {
        count[arr[i]]++;
        if (count[arr[i]] > maxCount) {
            maxCount = count[arr[i]];
        }
    }

    for(int i = 1000; i >= 0; i--) { 
        if (count[i] == maxCount) {
            cout << i << " ";
        }
    }

    cout << endl; 
    return 0;
}