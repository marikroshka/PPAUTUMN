#include <iostream>

using namespace std;

int main () {

    int n;

    cin >> n;

    int arr [n];

    vector<int> arr;

    for ( int i = 0; i < n; i++) {

        cout << sum (arr);
    }




    return 0;
}