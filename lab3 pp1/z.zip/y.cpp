#include<iostream>


using namespace std;


int main()
{

    int size;
    cin >> size;

    int arr[size];

    for(int i = 0; i <size; i++)
    {
        cin >> arr[i];
    }

    int cnt = 0;

    for(int i = 0; i < size;i++)
    {
        while(arr[i] > 0)
        {
            int a = arr[i] % 10;
            if(a == 0) cnt++;
            arr[i] /= 10;
        }
    }


    cout << cnt;

    return 0;
}